/* NanaDex: funcionamento offline.
   - A página: sempre tenta a internet primeiro (assim as atualizações aparecem) e usa a cópia guardada se estiver offline.
   - Dados das APIs (TCGdex e PokéAPI): internet primeiro, cópia guardada se falhar.
   - Imagens: usa a cópia guardada se existir (e guarda as novas), com limite de quantidade. */
const VERSAO = "v3";
const APP = "binder-app-" + VERSAO, DADOS = "binder-dados-" + VERSAO, IMAGENS = "binder-img-" + VERSAO;
const BASE = ["./", "./index.html", "./manifest.webmanifest", "./icon-192.png", "./icon-512.png"];
const LIMITE_IMAGENS = 300;

self.addEventListener("install", e => {
  e.waitUntil(caches.open(APP).then(c => Promise.all(BASE.map(u => c.add(u).catch(() => null)))).then(() => self.skipWaiting()));
});
self.addEventListener("activate", e => {
  e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => ![APP, DADOS, IMAGENS].includes(k)).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
async function redePrimeiro(req, nome) {
  const cache = await caches.open(nome);
  try {
    const r = await fetch(req);
    if (r && (r.ok || r.type === "opaque")) cache.put(req, r.clone());
    return r;
  } catch (e) {
    const c = await cache.match(req, { ignoreSearch: nome === APP });
    if (c) return c;
    if (nome === APP) { const i = await cache.match("./index.html") || await cache.match("./"); if (i) return i; }
    throw e;
  }
}
async function aparar(cache) {
  const ks = await cache.keys();
  for (let i = 0; i < ks.length - LIMITE_IMAGENS; i++) await cache.delete(ks[i]);
}
async function cachePrimeiro(req) {
  const cache = await caches.open(IMAGENS);
  const c = await cache.match(req);
  if (c) return c;
  const r = await fetch(req);
  if (r && (r.ok || r.type === "opaque")) { cache.put(req, r.clone()); aparar(cache); }
  return r;
}
self.addEventListener("fetch", e => {
  const req = e.request;
  if (req.method !== "GET") return;
  const u = new URL(req.url);
  if (req.mode === "navigate" || (u.origin === location.origin && !u.pathname.endsWith("sw.js"))) { e.respondWith(redePrimeiro(req, APP)); return; }
  if (u.hostname === "api.tcgdex.net" || u.hostname === "pokeapi.co") { e.respondWith(redePrimeiro(req, DADOS)); return; }
  if (u.hostname === "assets.tcgdex.net" || u.hostname === "raw.githubusercontent.com" || /cloudfront\.net$/.test(u.hostname) || u.hostname === "fonts.gstatic.com" || u.hostname === "fonts.googleapis.com") { e.respondWith(cachePrimeiro(req)); return; }
});
